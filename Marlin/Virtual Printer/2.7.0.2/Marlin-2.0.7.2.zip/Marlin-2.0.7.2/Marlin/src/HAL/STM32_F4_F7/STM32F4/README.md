# This HAL is for the STM32F407 MCU used with STM32Generic Arduino core by danieleff.

# Arduino core is located at:

https://github.com/danieleff/STM32GENERIC

Unzip it into [Arduino]/hardware folder

# This HAL is in development.

This HAL is a modified version of Chris Barr's Picoprint STM32F4 HAL.

